class KleinBottle extends Figure {
    constructor(scale = 3, count = 30) {
        super();
        const dU = (2 * Math.PI) / count;
        const dV = (2 * Math.PI) / count;
        const a = 2;

        // Generate points using the "figure-8" Klein bottle parametrization
        for (let i = 0; i <= count; i++) {
            const u = dU * i;
            for (let j = 0; j <= count; j++) {
                const v = dV * j;
                const cosU = Math.cos(u);
                const sinU = Math.sin(u);
                const cosHalfU = Math.cos(u / 2);
                const sinHalfU = Math.sin(u / 2);
                const sinV = Math.sin(v);
                const sin2V = Math.sin(2 * v);

                const r = a + cosHalfU * sinV - sinHalfU * sin2V;
                const x = r * cosU * scale;
                const y = r * sinU * scale;
                const z = (sinHalfU * sinV + cosHalfU * sin2V) * scale;

                this.points.push(new Point(x, y, z));
            }
        }

        const cols = count + 1;

        // Generate edges and polygons
        for (let i = 0; i < count; i++) {
            for (let j = 0; j < count; j++) {
                const idx = i * cols + j;

                // Horizontal edges (along v)
                this.edges.push(new Edge(
                    this.points[idx],
                    this.points[idx + 1]
                ));

                // Vertical edges (along u)
                this.edges.push(new Edge(
                    this.points[idx],
                    this.points[idx + cols]
                ));

                // Polygon (quad from 4 neighboring points)
                const p0 = this.points[idx];
                const p1 = this.points[idx + 1];
                const p2 = this.points[idx + cols + 1];
                const p3 = this.points[idx + cols];

                // Color based on position for nice visual effect
                const hue = Math.floor((i / count) * 360);
                const lightness = 40 + Math.floor((j / count) * 30);
                const color = `hsla(${hue}, 70%, ${lightness}%, 0.85)`;

                this.polygons.push(new Polygon([p0, p1, p2, p3], color));
            }
        }
    }
}
