class CalculatorPage {
    constructor() {
        this.a = 0;
        this.b = 0;
        this.operation = null;

        const calculator = {
            add: (a, b) => a + b,
            sub: (a, b) => a - b,
            mult: (a, b) => a * b,
            div: (a, b) => b === 0 ? 'Error' : a / b,
            sin: (a) => Math.asin(a),
            cos: (a) => Math.acos(a),
            tan: (a) => Math.atan(a),
            ctg: (a) => Math.acos(a) / Math.asin(a),
            sqr: (a) => a * a,
            sqrt: (a) => Math.sqrt(a),
            procent: (a, b) => a * b / 100,
        };
        this.calculator = calculator;

        const numbers = document.querySelectorAll('.calc-number');
        for (let i = 0; i < numbers.length; i++) {
            numbers[i].addEventListener('click', this.numberHandler);
        }

        const operations = document.querySelectorAll('.calc-operation');
        for (let i = 0; i < operations.length; i++) {
            operations[i].addEventListener('click', this.operationHandler);
        }
    }

    numberHandler = (event) => {
        const number = event.target.dataset.number;
        const input = document.getElementById('calc-input');
        input.value = (input.value === '0' || input.value === 'Error') ? number : input.value + number;
    }

    operationHandler = (event) => {
        const input = document.getElementById('calc-input');
        const _operation = event.target.dataset.operation;

        if (_operation === 'calculate') {
            this.b = Number(input.value);
            if (this.operation && this.calculator[this.operation]) {
                input.value = this.calculator[this.operation](this.a, this.b);
            }
            this.operation = null;
        } else if (_operation === 'clear') {
            input.value = '0';
            this.a = 0;
            this.b = 0;
            this.operation = null;
        } else {
            const unary = ['sin', 'cos', 'tan', 'ctg', 'sqr', 'sqrt'];
            if (unary.includes(_operation)) {
                this.a = Number(input.value);
                if (this.calculator[_operation]) {
                    input.value = this.calculator[_operation](this.a);
                }
                this.operation = null;
            } else {
                this.operation = _operation;
                this.a = Number(input.value);
                input.value = '0';
            }
        }
    }
}
