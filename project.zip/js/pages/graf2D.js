class Graph2D {
    constructor() {
        this.WIN = {
            left: -5,
            bottom: -5,
            width: 10,
            height: 10
        };

        this.funcs = [
            { f: (x) => x * x, color: '#f00', width: 3 },
            { f: (x) => Math.sin(x), color: '#0f0', width: 1 },
            { f: (x) => Math.cos(x), color: '#007' },
        ];

        this.canMove = false;

        this.canvas = new Canvas({
            id: 'graph2D',
            WIN: this.WIN,
            width: 600,
            height: 600,
            callbacks: {
                wheel: (event) => this.wheelHandler(event),
                mouseup: () => this.mouseupHandler(),
                mousedown: () => this.mousedownHandler(),
                mousemove: (event) => this.mousemoveHandler(event),
                mouseleave: () => this.mouseleaveHandler()
            }
        });

        this.render();

        // Button handlers
        const zoomIn = document.getElementById('zoomIn');
        if (zoomIn) zoomIn.addEventListener('click', () => {
            this.WIN.width *= 0.8;
            this.WIN.height *= 0.8;
            this.render();
        });

        const zoomOut = document.getElementById('zoomOut');
        if (zoomOut) zoomOut.addEventListener('click', () => {
            this.WIN.width *= 1.25;
            this.WIN.height *= 1.25;
            this.render();
        });

        const reset = document.getElementById('reset');
        if (reset) reset.addEventListener('click', () => {
            this.WIN.left = -5;
            this.WIN.bottom = -5;
            this.WIN.width = 10;
            this.WIN.height = 10;
            this.render();
        });

        const moveLeft = document.getElementById('moveLeft');
        if (moveLeft) moveLeft.addEventListener('click', () => {
            this.WIN.left -= this.WIN.width * 0.1;
            this.render();
        });

        const moveRight = document.getElementById('moveRight');
        if (moveRight) moveRight.addEventListener('click', () => {
            this.WIN.left += this.WIN.width * 0.1;
            this.render();
        });

        const moveUp = document.getElementById('moveUp');
        if (moveUp) moveUp.addEventListener('click', () => {
            this.WIN.bottom += this.WIN.height * 0.1;
            this.render();
        });

        const moveDown = document.getElementById('moveDown');
        if (moveDown) moveDown.addEventListener('click', () => {
            this.WIN.bottom -= this.WIN.height * 0.1;
            this.render();
        });
    }

    printOXY() {
        const { left, bottom, width, height } = this.WIN;
        const right = width + left;
        const top = height + bottom;
        const color = '#ddd';

        this.canvas.line(left, 0, right, 0, '#000', 2);
        this.canvas.line(0, bottom, 0, top, '#000', 2);

        for (let i = 1; i < right; i++) {
            this.canvas.line(i, bottom, i, top, color, 1);
            this.canvas.line(i, 0.1, i, -0.1, '#000', 1);
        }
        for (let i = -1; i > left; i--) {
            this.canvas.line(i, bottom, i, top, color, 1);
            this.canvas.line(i, 0.1, i, -0.1, '#000', 1);
        }
        for (let i = 1; i < top; i++) {
            this.canvas.line(left, i, right, i, color, 1);
            this.canvas.line(0.1, i, -0.1, i, '#000', 1);
        }
        for (let i = -1; i > bottom; i--) {
            this.canvas.line(left, i, right, i, color, 1);
            this.canvas.line(0.1, i, -0.1, i, '#000', 1);
        }

        this.canvas.text(right - 0.3, -0.3, 'X', '#000', '12px Arial');
        this.canvas.text(0.3, top - 0.3, 'Y', '#000', '12px Arial');
    }

    printFunction(func) {
        let x = this.WIN.left;
        const dx = this.WIN.width / 100;
        while (x < this.WIN.width + this.WIN.left) {
            this.canvas.line(x, func.f(x), x + dx, func.f(x + dx), func.color, func.width);
            x += dx;
        }
    }

    render() {
        this.canvas.clear();
        this.printOXY();
        for (let i = 0; i < this.funcs.length; i++) {
            if (this.funcs[i] && this.funcs[i].f) {
                this.printFunction(this.funcs[i]);
            }
        }
        this.canvas.text(3, 4, 'График Canvas', '#000', 'bold 18px Arial');
    }

    wheelHandler(event) {
        event.preventDefault();
        const delta = (event.deltaY > 0) ? -0.2 : 0.2;
        this.WIN.width += delta;
        this.WIN.height += delta;
        this.WIN.left -= delta / 2;
        this.WIN.bottom -= delta / 2;
        this.render();
    }

    mousedownHandler() { this.canMove = true; }
    mouseupHandler() { this.canMove = false; }
    mouseleaveHandler() { this.canMove = false; }

    mousemoveHandler(event) {
        if (this.canMove) {
            this.WIN.left -= this.canvas.sx(event.movementX);
            this.WIN.bottom -= this.canvas.sy(event.movementY);
            this.render();
        }
    }
}
