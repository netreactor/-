class Graph3D {
    constructor() {
        this.WIN = {
            left: -10,
            bottom: -10,
            width: 20,
            height: 20,
            Camera: new Point(0, 0, 50),
            Focus: new Point(0, 0, 30),
        };

        this.canMove = false;
        this.scene = new Cube();
        this.Math3D = new Math3D(this.WIN);

        this.canvas = new Canvas({
            id: 'graph3D',
            WIN: this.WIN,
            width: 600,
            height: 600,
            callbacks: {
                wheel: (event) => this.wheelHandler(event),
                mousemove: (event) => this.mouseMoveHandler(event),
                mouseup: () => this.mouseUpHandler(),
                mousedown: () => this.mouseDownHandler(),
                mouseleave: () => this.mouseLeaveHandler()
            }
        });

        // Figure switching
        const selectFigure = document.getElementById('selectFigure');
        if (selectFigure) {
            selectFigure.addEventListener('change', () => {
                const value = selectFigure.value;
                if (value === 'cube') this.scene = new Cube();
                else if (value === 'sphere') this.scene = new Sphere();
                else if (value === 'klein') this.scene = new KleinBottle();
                this.render();
            });
        }

        this.render();
    }

    wheelHandler(event) {
        event.preventDefault();
        const delta = (event.wheelDelta > 0 || event.deltaY < 0) ? 1.1 : 0.9;
        this.scene.points.forEach(point => this.Math3D.zoom(delta, point));
        this.render();
    }

    mouseDownHandler() { this.canMove = true; }
    mouseUpHandler() { this.canMove = false; }
    mouseLeaveHandler() { this.canMove = false; }

    mouseMoveHandler(event) {
        if (this.canMove) {
            const alphaX = (event.movementX * Math.PI / 360);
            const alphaY = (event.movementY * Math.PI / 360);
            this.scene.points.forEach(point => {
                this.Math3D.rotateOy(alphaX, point);
                this.Math3D.rotateOx(alphaY, point);
            });
            this.render();
        }
    }

    render() {
        this.canvas.clear();

        // Draw edges
        this.scene.edges.forEach(edge => {
            const { p1, p2 } = edge;
            this.canvas.line(
                this.Math3D.xs(p1), this.Math3D.ys(p1),
                this.Math3D.xs(p2), this.Math3D.ys(p2),
                '#555', 1
            );
        });

        // Draw polygons with painter's algorithm
        if (this.scene.polygons.length > 0) {
            this.scene.polygons.forEach(polygon => {
                this.Math3D.calcCenter(polygon);
                this.Math3D.calcDistance(polygon, this.WIN.Camera, 'distance');
            });

            this.Math3D.sortByArtist(this.scene.polygons);

            this.scene.polygons.forEach(polygon => {
                this.canvas.polygon(polygon.points.map(point => ({
                    x: this.Math3D.xs(point),
                    y: this.Math3D.ys(point)
                })), polygon.color);
            });
        }
    }
}
