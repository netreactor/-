class Matrix {
    constructor() {
        const buttons = document.querySelectorAll('.fill-matrix');
        for (let i = 0; i < buttons.length; i++) {
            buttons[i].addEventListener('click', this.getMatrixHandler);
        }
    }

    getMatrixHandler = (event) => {
        const length = Number(document.getElementById('matrix-size').value);
        if (length > 0) {
            const name = event.target.dataset.method;
            const mathMatrix = new MathMatrix();
            if (mathMatrix[name]) {
                const arr = mathMatrix[name](length);
                const resultDiv = document.getElementById('matrix-result');

                const table = document.createElement('table');
                table.style.borderCollapse = 'collapse';
                table.style.marginTop = '10px';

                for (let i = 0; i < arr.length; i++) {
                    const row = document.createElement('tr');
                    for (let j = 0; j < arr[i].length; j++) {
                        const cell = document.createElement('td');
                        cell.textContent = arr[i][j];
                        cell.style.border = '1px solid black';
                        cell.style.padding = '8px';
                        cell.style.textAlign = 'center';
                        row.appendChild(cell);
                    }
                    table.appendChild(row);
                }

                resultDiv.innerHTML = '';
                resultDiv.appendChild(table);
            }
        }
    }
}
