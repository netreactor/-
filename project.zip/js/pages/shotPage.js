class Shot {
    constructor() {
        this.target = new Target();

        const shotBtn = document.getElementById('shotTarget');
        if (shotBtn) {
            shotBtn.addEventListener('click', this.shotHandler);
        }

        const randomBtn = document.getElementById('RandomshotTarget');
        if (randomBtn) {
            randomBtn.addEventListener('click', this.randomShotHandler);
        }
    }

    shotHandler = () => {
        const x = Number(document.getElementById('x').value);
        const y = Number(document.getElementById('y').value);
        if (!isNaN(x) && !isNaN(y)) {
            const result = this.target.shot(x, y);
            document.getElementById('result').innerHTML =
                '<b>Результат попадания (самостоятельный ввод): </b>' + result;
        } else {
            alert('Введите корректные координаты');
        }
    }

    randomShotHandler = () => {
        const count = Number(document.getElementById('randomshot').value);
        if (!isNaN(count) && count > 0) {
            const results = [];
            let sum = 0;
            for (let i = 0; i < count; i++) {
                const x = (Math.random() * 2) - 1;
                const y = (Math.random() * 2) - 1;
                const result = this.target.shot(x, y);
                sum += result;
                results.push(result);
            }
            document.getElementById('randomResult').innerHTML =
                '<b>Результат попадания, очки попаданий (Генерация выстрелов): </b>' + results.join(', ');
            document.getElementById('randomResultsum').innerHTML =
                '<b>Результат попадания сумма очков (Генерация выстрелов): </b>' + sum;
        } else {
            alert('Введите корректное количество выстрелов (число больше 0)');
        }
    }
}
