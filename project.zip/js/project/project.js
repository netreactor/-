window.onload = function () {
    new Tabs();
    new CalculatorPage();
    new Matrix();
    new Shot();
    new Graph2D();
    new Graph3D();
}
